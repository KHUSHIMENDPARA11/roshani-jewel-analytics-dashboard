CREATE TABLE [dbo].[DimCustomer] (

	[CustomerID] varchar(8000) NULL, 
	[CustomerName] varchar(8000) NULL, 
	[AgeGroup] varchar(8000) NULL, 
	[City] varchar(8000) NULL, 
	[State] varchar(8000) NULL, 
	[CustomerSegment] varchar(8000) NULL
);