CREATE TABLE [dbo].[DimDate] (

	[Date] date NULL, 
	[Month] varchar(8000) NULL, 
	[Quarter] varchar(8000) NULL, 
	[Year] bigint NULL
);