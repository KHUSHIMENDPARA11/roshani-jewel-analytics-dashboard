CREATE TABLE [dbo].[DimProduct] (

	[ProductID] varchar(8000) NULL, 
	[ProductName] varchar(8000) NULL, 
	[Category] varchar(8000) NULL, 
	[Material] varchar(8000) NULL, 
	[CostPrice] bigint NULL, 
	[SellingPrice] bigint NULL, 
	[Supplier] varchar(8000) NULL
);