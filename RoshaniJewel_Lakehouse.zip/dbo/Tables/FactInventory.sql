CREATE TABLE [dbo].[FactInventory] (

	[ProductID] varchar(8000) NULL, 
	[StockAvailable] bigint NULL, 
	[ReorderLevel] bigint NULL, 
	[WarehouseLocation] varchar(8000) NULL
);