CREATE TABLE [dbo].[FactMarketing] (

	[CampaignID] varchar(8000) NULL, 
	[CampaignName] varchar(8000) NULL, 
	[Channel] varchar(8000) NULL, 
	[Spend] bigint NULL, 
	[Clicks] bigint NULL, 
	[Conversions] bigint NULL, 
	[RevenueGenerated] bigint NULL
);