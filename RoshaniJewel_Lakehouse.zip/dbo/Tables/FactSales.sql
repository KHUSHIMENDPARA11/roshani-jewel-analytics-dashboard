CREATE TABLE [dbo].[FactSales] (

	[OrderID] varchar(8000) NULL, 
	[OrderDate] date NULL, 
	[CustomerID] varchar(8000) NULL, 
	[ProductID] varchar(8000) NULL, 
	[Quantity] bigint NULL, 
	[UnitPrice] bigint NULL, 
	[Discount] bigint NULL, 
	[ShippingCost] bigint NULL, 
	[SalesChannel] varchar(8000) NULL
);